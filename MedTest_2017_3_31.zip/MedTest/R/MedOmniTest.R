MedOmniTest <-
function(x, y, m.list, z=NULL, nperm=9999) {

save.seed <- get(".Random.seed", .GlobalEnv)
perm.mat <-  matrix(NA, nrow=nperm, ncol=length(m.list))

obs.vec <- numeric(length(m.list))

if (is.null(z)) {
x.adj <- resid(lm(x ~ 1))
} else {
x.adj <- resid(lm(x ~ z))
}

if (is.null(z)) {
y.adj <- resid(lm(y ~ x)) 
} else {
y.adj <- resid(lm(y ~ x + z))
}
for (j in 1:length(m.list)) {
assign(".Random.seed", save.seed, .GlobalEnv)

dmat <- as.matrix(m.list[[j]])
n <- nrow(dmat)
dmat <- -dmat^2/2

G <- mean(dmat) + dmat - rowMeans(dmat) - matrix(rep(1, n), ncol=1) %*% colMeans(dmat)

obj <- eigen(G, symmetric=TRUE)
lambda <- obj$values
u <- obj$vectors
u <- u[, lambda > 0, drop=FALSE]
lambda <- lambda[lambda > 0]

obs.vec[j]  <- sum(lambda * abs(t(u) %*% x.adj)  * abs(t(u) %*% y.adj))

perm.mat[, j] <- sapply(1:nperm, function(i) {
x.adj.p <- x.adj[sample(n)]
y.adj.p <- y.adj[sample(n)]
f1.f2.p <- sum(lambda * abs(t(u) %*% x.adj)  * abs(t(u) %*% y.adj.p))
f2.f1.p <- sum(lambda * abs(t(u) %*% x.adj.p)  * abs(t(u) %*% y.adj))
f1.p.f2.p <- sum(lambda * abs(t(u) %*% x.adj.p)  * abs(t(u) %*% y.adj.p))
max(f1.f2.p, f2.f1.p, f1.p.f2.p)
})

}
# marginal p values
margPs <- colMeans(rbind(sweep(perm.mat, 2, obs.vec, '>'), rep(1, length(m.list)))) 


perm.mat.p <- 1 - (apply(perm.mat, 2, rank) - 1) / nrow(perm.mat)


list(margPs = margPs, 
#margP = min(min(margPs * length(m.list)), 1),
permP = mean(c(rowMins(perm.mat.p) <= min(margPs), 1)))

}
